import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ItemStatusControllerDirective } from '../../directives/item-status-controller/item-status-controller';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  @ViewChild(ItemStatusControllerDirective) container: ItemStatusControllerDirective;
  constructor(public navCtrl: NavController) {

  }

  tryPrevious() {
    this.container.controlUndone();
  }

}
