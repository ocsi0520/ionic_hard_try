import { EventEmitter } from "@angular/core";

export enum Status {
  NotActive,
  Active,
  Ready
}

export interface IStatus {
  empty(): void;
  setStatus(status: Status): void;
  done: EventEmitter<any>;
  value: any;
}
