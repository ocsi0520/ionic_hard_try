import { Component, EventEmitter, Output } from '@angular/core';
import { IStatus, Status } from '../../interfaces/status';
/**
 * Generated class for the InputControlComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'input-control',
  templateUrl: 'input-control.html'
})
export class InputControlComponent implements IStatus {
  @Output() done: EventEmitter<any> = new EventEmitter();

  value: any;
  hidden: boolean;
  enabled: boolean;
  currentClass: string;
  currentStatus: Status;

  constructor() {
    //this.setStatus(Status.NotActive);
    this.currentClass = 'active';
  }

  empty(): void {
    
  }
  setStatus(status: Status): void {
    this.currentStatus = status;
    switch (status) {
      case Status.NotActive:
        this.hidden = true;
        this.enabled = false;
        this.currentClass = 'active';
        break;

      case Status.Active:
        this.hidden = false;
        this.enabled = true;
        this.currentClass = 'ready';
        break;

      case Status.Ready:
        this.hidden = false;
        this.enabled = false;
        break;

    }
  }

  gotClicked() {
    if (this.enabled) {
      this.done.emit();
    }
  }

}
