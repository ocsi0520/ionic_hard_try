import { NgModule } from '@angular/core';
import { InputControlComponent } from './input-control/input-control';
@NgModule({
	declarations: [
    InputControlComponent],
	imports: [],
	exports: [
    InputControlComponent]
})
export class ComponentsModule {}
